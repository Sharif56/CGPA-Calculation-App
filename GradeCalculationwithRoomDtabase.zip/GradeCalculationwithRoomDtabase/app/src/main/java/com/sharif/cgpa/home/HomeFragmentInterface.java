package com.sharif.cgpa.home;

import com.sharif.cgpa.model.Semister;

public interface HomeFragmentInterface {
    void onSemisterItemClick(Semister semister);
}
